<?php
$bot_token = "6408045722:AAEn-tqBILGjh_G639alBCRAMPGVuI4bees"; /* bot token */
$chat_id = "651093476"; /* chatid */

?>